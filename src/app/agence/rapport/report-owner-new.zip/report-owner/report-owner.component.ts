import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { Globals } from '@theme/utils/globals';
import { OwnerService } from '@service/owner/owner.service';
import { FormField } from '@theme/shared/components/search/search.component';
import { HouseService } from '@service/house/house.service';
import { debounceTime } from 'rxjs/internal/operators/debounceTime';
import { distinctUntilChanged } from 'rxjs/internal/operators/distinctUntilChanged';
import { RepaymentService } from '@service/repayment/repayment.service';
import { OwnerReportService } from '@service/owner-report/owner-report.service';
import { SettingService } from '@service/setting/setting.service';

@Component({
  selector: 'app-report-owner',
  templateUrl: './report-owner.component.html',
  styleUrls: ['./report-owner.component.scss']
})
export class ReportOwnerComponent implements OnInit {

  filter: any;

  publicUrl = environment.publicUrl;

  global = {country: Globals.country, device: Globals.device}

  userSession = Globals.user

  type: string = 'COMPTE'

  ownersData: any[] = []
  owners: any[] = []

  housesData: any[] = []
  houses: any[] = []

  typeRow = [
    { label: 'COMPTE', value: 'COMPTE' },
    { label: 'RECOUVREMENT', value: 'RECOUVREMENT' },
    { label: 'PAIEMENT', value: 'PAIEMENT' },
    { label: 'REVERSEMENT', value: 'REVERSEMENT' },
    { label: 'SITUATION DES BIENS', value: 'SITUATION_BIEN' },
    { label: 'COMMISSION ', value: 'COMMISSION' }
  ]

  countRow = [
    { key: "0", value: "Tout" },
    { key: "1", value: "1" },
    { key: "5", value: "5" },
    { key: "10", value: "10" },
    { key: "25", value: "25" },
    { key: "50", value: "50" },
    { key: "100", value: "100" },
    { key: "200", value: "200" }
  ];

  orderRow = [
    { key: "ASC", value: "Croissant" },
    { key: "DESC", value: "Décroissant" },
  ];

  etatRow = [
    { key: "VALIDE", value: "Validé" },
    { key: "INVALIDE", value: "En attente de validation" },
  ];

  inputs: FormField<string>[] = [
    new FormField<string>({
      controlType: "dropdown",
      key: "owner",
      label: "Propriétaire",
      top: true,
      options: this.owners,
      groups: ["ALL"],
      column: 4
    }),
    new FormField<string>({
      controlType: "dropdown",
      key: "house",
      label: "Locative",
      top: true,
      options: this.houses,
      multiple: true,
      groups: ["COMPTE", "PAIEMENT", "REVERSEMENT"],
      column: 4
    }),
    new FormField<string>({
      controlType: "textbox",
      key: 'dateD',
      type: 'date',
      label: 'Date de début',
      groups: ['ALL'],
      top: false,
      column: 3
    }),
    new FormField<string>({
      controlType: "textbox",
      key: 'dateF',
      type: 'date',
      label: 'Date de fin',
      groups: ['ALL'],
      top: false,
      column: 3
    }),
    new FormField<string>({
      controlType: "dropdown",
      key: 'etat',
      label: 'Etat',
      options: this.etatRow,
      groups: ['PAIEMENT'],
      top: false,
      column: 2
    }),
    // new FormField<string>({
    //   controlType: "textbox",
    //   type: 'number',
    //   key: 'min',
    //   label: 'Montant minimum',
    //   groups: ['PAIEMENT'],
    //   top: false,
    //   column: 2
    // }),
    // new FormField<string>({
    //   controlType: "textbox",
    //   type: 'number',
    //   key: 'max',
    //   label: 'Montant maximum',
    //   groups: ['PAIEMENT'],
    //   top: false,
    //   column: 2
    // }),
    new FormField<string>({
      controlType: "textbox",
      key: 'dateCreation',
      type: 'date',
      label: 'Date de création',
      groups: ['ALL'],
      top: false,
      column: 2
    }),
    new FormField<string>({
      controlType: "dropdown",
      key: 'order',
      label: 'Ordre',
      options: this.orderRow,
      groups: ['ALL'],
      top: false,
      column: 2
    }),
    new FormField<string>({
      controlType: "dropdown",
      key: 'count',
      label: 'Nombre',
      options: this.countRow,
      groups: ['ALL'],
      top: false,
      column: 2
    })
  ]

  entries: any[] = []

  criterias: any[] = []

  settings: any

  constructor(
    public router: Router,
    private ownerService: OwnerService,
    private houseService: HouseService,
    private repaymentService: RepaymentService,
    private ownerReportService: OwnerReportService,
    private settingService: SettingService
  ) {
    this.ownerService.getList('ALL').subscribe( res => {
      this.ownersData = res;
      for (const key in this.ownersData) {
        this.owners.push({
          key: this.ownersData[key].id,
          value: this.ownersData[key].nom
        });
      }
    });
    this.settingService.getSingle().subscribe((res) => {
      if (res) {
        this.settings = res
      }
    })
  }

  ngOnInit(): void { }

  // onFilter($event) {
  //   this.filter = $event
  //   this.ownerService.getReport(this.userSession?.agencyKey, this.userSession?.uuid, this.filter)
  // }

  onFilter($event) {
    console.log($event)
  }

  onChangeLoad($event) {
    console.log($event)
  }

  searchChanged($event) {
    $event.get("owner").valueChanges
      .pipe(debounceTime(500), distinctUntilChanged())
      .subscribe((data) => {
        if (data) {
          let controls = $event.controls
          controls['house'].reset()
          console.log(controls['house'])
          console.log(controls)
          let filtered = this.ownersData.filter((owner) => owner.id === data)
          console.log(filtered)
          this.houseService.getList(filtered[0].uuid).subscribe(res => {
            this.housesData = res;
            this.houses = []
            for (const key in this.housesData) {
              this.houses.push({
                key: this.housesData[key].id,
                value: this.housesData[key].nom
              })
            }
            this.inputs.forEach((input) => {
              if (input.key === "house") {
                input.options = this.houses
              }
            })
          })
        }
    });
  }

  onPreview($event) {
    console.log($event)
    this.type = $event.type
    let type = $event.type
    let data = $event
    this.getCriterias(data)
    console.log(this.criterias)
    data.agencyKey = this.userSession.agencyKey
    if (type === "COMPTE") {
      this.ownerReportService.checkData(data).subscribe(res => {
        console.log(res)
        this.entries = []
        this.entries = res.data
        // res.data.forEach((entry: any) => {
        //   entry.repayments.forEach((repayment: any, index) => {
        //     this.entries.push({
        //       numero: (index + 1),
        //       reference: repayment?.code,
        //       contrat_type: repayment?.type,
        //       owner: repayment?.owner?.nom,
        //       dateD: repayment?.dateD,
        //       dateF: repayment?.dateF,
        //       amount: repayment?.montant,
        //       commission: repayment?.commission,
        //       to_return: repayment?.aReverser,
        //       returned: repayment?.verse
        //     })
        //   })
        // })
        console.log(this.entries)
      })
    } else if (type === "") {

    } else if (type === "PAIEMENT") {
      this.ownerReportService.checkData(data).subscribe(res => {
        console.log(res)
        this.entries = []
        res.data.forEach((entry: any, index) => {
          this.entries.push({
            numero: (index + 1),
            numero_invoice: entry?.code,
            owner: entry?.invoice?.contract?.rental?.house?.owner?.searchableTitle,
            house: entry?.invoice?.contract?.rental?.house?.nom,
            tenant: entry?.invoice?.contract?.tenant?.searchableTitle,
            state: entry?.etat,
            date: entry?.date,
            mode: entry?.mode,
            amount: entry?.montant
          })
        })
      })
    } else if (type === "REVERSEMENT") {
      this.ownerReportService.checkData(data).subscribe(res => {
        console.log(res)
        this.entries = []
        res.data.forEach((entry: any, index) => {
          this.entries.push({
            numero: (index + 1),
            reference: entry?.code,
            contrat_type: entry?.type,
            owner: entry?.owner?.nom,
            dateD: entry?.dateD,
            dateF: entry?.dateF,
            amount: entry?.montant,
            commission: entry?.commission,
            to_return: entry?.aReverser,
            returned: entry?.verse
          })
        })
      })
    } else if (type === "") {
      
    } else if (type === "") {
      
    }
  }

  getTotal(data, attribute) {
    let total = 0
    for (const item of data) {
      if (item.hasOwnProperty(attribute)) {
        total += item[attribute];
      }
    }
    return total
  }

  getCriterias(data) {
    this.criterias = []
    for (const [key, value] of Object.entries(data)) {
      if (value) {
        let name
        let new_value
        if (key === "type") {
          name = "Type"
        } else if (key === "owner") {
          name = "Propriétaire"
          let filtered = this.owners.filter((owner) => owner.key === value)
          if (filtered && filtered.length > 0) {
            new_value = filtered[0].value
          }
        } else if (key === "house") {
          name = "Locative"
          let filtered = this.houses.filter((house) => house.key === value)
          if (filtered && filtered.length > 0) {
            new_value = filtered[0].value
          }
        } else if (key === "dateD") {
          name = "Date de début"
        } else if (key === "dateF") {
          name = "Date de fin"
        } else if (key === "dateCreation") {
          name = "Date de création"
        } else if (key === "etat") {
          name = "Etat"
        } else if (key === "count") {
          name = "Nombre"
        } else if (key === "order") {
          name = "Ordre"
        } else if (key === "agencyKey") {
          name = "Agence"
        }
        if (name !== "Agence") {
          this.criterias.push({
            name: name,
            value: new_value ? new_value : value
          })
        }
      }
    }
  }

}
